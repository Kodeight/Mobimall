import React, { useState, useRef, useEffect } from "react";
import { FurnitureProduct, Material } from "../types";
import { Maximize2, Compass, Layers, RotateCcw, HelpCircle, Sun, Sparkles } from "lucide-react";
import { gsap } from "gsap";

const SOFA_3_PLACES_PRODUCT = {
  id: "p-casbah-sofa", // keeps id consistent for planner mapping
  name: "Canapé Blanc de 3 Places",
  arabicName: "أريكة بيضاء ثلاثية المقاعد",
  collection: "El Djazaïr",
  basePrice: 485000,
  description: "L'harmonie ultime entre luxe discret et confort absolu. Ce canapé trois places d'exception se pare d'un habillage en tissu bouclé blanc impérial de prestige. Une assise profonde reposant sur un socle robuste en noyer massif de l'Atlas, entièrement sculptée et façonnée par nos maîtres ébénistes.",
  materials: [
    {
      id: "m-boucle-blanc",
      name: "Bouclé Blanc Impérial",
      type: "Tissu de Prestige",
      colorHex: "#f8fafc",
      extraPrice: 0
    }
  ]
};

const SOFA_HOTSPOTS = [
  {
    id: "spot-seat",
    x: 0,
    y: 0.45,
    z: -0.1,
    offsetGroup: "cushion" as const,
    title: "Assise Triple Confort",
    subtitle: "Remplissage Organique",
    price: "485 000 DZD",
    desc: "Mousse haute résilience enveloppée d'un duvet de plumes d'oie, offrant un confort d'accueil moelleux incomparable."
  },
  {
    id: "spot-back",
    x: 0.4,
    y: 0.15,
    z: 0.4,
    offsetGroup: "backrest" as const,
    title: "Dossier de Prestige",
    subtitle: "Soutien Absolu",
    price: "Inclus",
    desc: "Inclinaison calculée scientifiquement et structure robuste renforcée pour un maintien parfait du dos."
  },
  {
    id: "spot-arms",
    x: -1.05,
    y: 0.25,
    z: -0.2,
    offsetGroup: "cushion" as const,
    title: "Accoudoirs Capitonnés",
    subtitle: "Travail Artisanal",
    price: "Inclus",
    desc: "Revêtus d'un tissu bouclé précieux, rembourrés à la main pour un toucher extrêmement doux."
  }
];

export default function ShowroomHero({ 
  onPlaceInPlanner,
  selectedProduct
}: { 
  onPlaceInPlanner: (productId: string) => void;
  selectedProduct?: FurnitureProduct;
}) {
  const product = SOFA_3_PLACES_PRODUCT;
  const selectedMaterial = product.materials[0];

  const [exploded, setExploded] = useState<number>(0); // 0 (normal) to 1 (fully exploded)
  const [angleX, setAngleX] = useState<number>(-0.6); // Radians horizontal orbit
  const [angleY, setAngleY] = useState<number>(0.2);  // Radians vertical orbit
  const [zoom, setZoom] = useState<number>(1.2);
  const [showMeasurements, setShowMeasurements] = useState<boolean>(true);
  const [mouseLightPos, setMouseLightPos] = useState({ x: 0, y: 0 });

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const isDragging = useRef<boolean>(false);
  const prevMousePos = useRef({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement>(null);

  const [activeHotspotId, setActiveHotspotId] = useState<string | null>(null);
  const tooltipRef = useRef<HTMLDivElement>(null);

  // GSAP reveal animation for active tooltip
  useEffect(() => {
    if (activeHotspotId && tooltipRef.current) {
      gsap.fromTo(
        tooltipRef.current,
        { opacity: 0, scale: 0.85, y: 15 },
        { opacity: 1, scale: 1, y: 0, duration: 0.4, ease: "back.out(1.5)" }
      );
    }
  }, [activeHotspotId]);

  const getHotspot2DPos = (x: number, y: number, z: number, offsetGroup: "base" | "cushion" | "backrest") => {
    const width = 1000;
    const height = 1000;
    const cosX = Math.cos(angleX);
    const sinX = Math.sin(angleX);
    const cosY = Math.cos(angleY);
    const sinY = Math.sin(angleY);

    // Apply exploded view vector offsets
    let ex = 0, ey = 0, ez = 0;
    if (exploded > 0) {
      if (offsetGroup === "cushion") {
        ey = -0.4 * exploded;
      } else if (offsetGroup === "backrest") {
        ez = 0.3 * exploded;
        ey = -0.15 * exploded;
      } else if (offsetGroup === "base") {
        ey = 0.2 * exploded;
      }
    }

    const px = x + ex;
    const py = y + ey;
    const pz = z + ez;

    // Apply horizontal rotation (Y-axis orbit)
    const rx = px * cosX - pz * sinX;
    const rz = px * sinX + pz * cosX;

    // Apply vertical rotation (X-axis orbit)
    const rry = py * cosY - rz * sinY;
    const rrz = py * sinY + rz * cosY;

    // Scale & Perspective
    const distance = 4.0;
    const scale = (width * 0.45 * zoom) / (distance + rrz);

    return {
      x: (width / 2 + rx * scale) / 10, // Percent (0 - 100)
      y: (height / 2 + rry * scale) / 10,
      depth: rrz,
      visible: rrz > -distance
    };
  };

  // Floating dust particles
  const particles = useRef<Array<{ x: number; y: number; z: number; size: number; speed: number }>>([]);
  if (particles.current.length === 0) {
    for (let i = 0; i < 40; i++) {
      particles.current.push({
        x: (Math.random() - 0.5) * 3,
        y: (Math.random() - 0.5) * 2,
        z: (Math.random() - 0.5) * 3,
        size: Math.random() * 2 + 1,
        speed: Math.random() * 0.003 + 0.001
      });
    }
  }

  // Handle lighting color presets (Strictly Moon theme)
  const currentLighting = {
    ambient: { r: 15, g: 20, b: 35 },
    directional: { r: 147, g: 197, b: 253, intensity: 0.8 },
    bgColor: "from-[#02040a] via-[#070b18] to-[#010205]",
    shadowColor: "rgba(0, 0, 5, 0.6)"
  };

  // Mouse move over hero container affects light source coordinates
  const handleMouseMoveLight = (e: React.MouseEvent) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 2 - 1; // -1 to 1
    const y = ((e.clientY - rect.top) / rect.height) * 2 - 1; // -1 to 1
    setMouseLightPos({ x, y });
  };

  // Drag-to-orbit triggers
  const handleMouseDown = (e: React.MouseEvent) => {
    isDragging.current = true;
    prevMousePos.current = { x: e.clientX, y: e.clientY };
    setActiveHotspotId(null);
  };

  useEffect(() => {
    const handleMouseUp = () => { isDragging.current = false; };
    window.addEventListener("mouseup", handleMouseUp);
    return () => window.removeEventListener("mouseup", handleMouseUp);
  }, []);

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging.current) return;
    const deltaX = e.clientX - prevMousePos.current.x;
    const deltaY = e.clientY - prevMousePos.current.y;
    
    setAngleX(prev => prev + deltaX * 0.007);
    setAngleY(prev => Math.max(-Math.PI / 3, Math.min(Math.PI / 3, prev + deltaY * 0.007)));
    
    prevMousePos.current = { x: e.clientX, y: e.clientY };
  };

  // 3D Canvas Rendering Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationId: number;

    const render = () => {
      const width = canvas.width;
      const height = canvas.height;

      // Clear with dark luxurious backdrop
      ctx.clearRect(0, 0, width, height);

      // Draw subtle background radial glow representing the moon rays
      const glow = ctx.createRadialGradient(width / 2, height / 2, 50, width / 2, height / 2, width * 0.5);
      glow.addColorStop(0, "rgba(22, 38, 70, 0.3)");
      glow.addColorStop(0.5, "rgba(10, 15, 30, 0.15)");
      glow.addColorStop(1, "rgba(0, 0, 0, 0)");
      ctx.fillStyle = glow;
      ctx.fillRect(0, 0, width, height);

      // Update and Draw floating dust particles
      ctx.save();
      particles.current.forEach((p) => {
        // Drifting animation
        p.y -= p.speed;
        if (p.y < -1) p.y = 1;
        
        const proj = getHotspot2DPos(p.x, p.y, p.z, "base");
        if (proj.visible) {
          ctx.fillStyle = "rgba(147, 197, 253, 0.18)";
          ctx.beginPath();
          ctx.arc(proj.x * 10, proj.y * 10, p.size, 0, Math.PI * 2);
          ctx.fill();
        }
      });
      ctx.restore();

      // Draw soft floor shadow underneath the sofa
      ctx.save();
      ctx.translate(width / 2, height / 2 + 180 * zoom);
      const shadowGrad = ctx.createRadialGradient(0, 0, 10, 0, 0, 240 * zoom);
      shadowGrad.addColorStop(0, currentLighting.shadowColor);
      shadowGrad.addColorStop(0.6, "rgba(0, 0, 3, 0.25)");
      shadowGrad.addColorStop(1, "rgba(0, 0, 0, 0)");
      ctx.fillStyle = shadowGrad;
      ctx.scale(1.8, 0.4);
      ctx.beginPath();
      ctx.arc(0, 0, 120, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      const cosX = Math.cos(angleX);
      const sinX = Math.sin(angleX);
      const cosY = Math.cos(angleY);
      const sinY = Math.sin(angleY);

      // Define standard 3D vertices projection helper
      const project = (x: number, y: number, z: number, offsetGroup: "base" | "cushion" | "backrest") => {
        let ex = 0, ey = 0, ez = 0;
        if (exploded > 0) {
          if (offsetGroup === "cushion") {
            ey = -0.4 * exploded;
          } else if (offsetGroup === "backrest") {
            ez = 0.3 * exploded;
            ey = -0.15 * exploded;
          } else if (offsetGroup === "base") {
            ey = 0.2 * exploded;
          }
        }

        const px = x + ex;
        const py = y + ey;
        const pz = z + ez;

        let rx = px * cosX - pz * sinX;
        let rz = px * sinX + pz * cosX;

        let rry = py * cosY - rz * sinY;
        let rrz = py * sinY + rz * cosY;

        const distance = 4.0;
        const scale = (width * 0.45 * zoom) / (distance + rrz);
        
        return {
          sx: width / 2 + rx * scale,
          sy: height / 2 + rry * scale,
          depth: rrz
        };
      };

      interface Polygon3D {
        points: { sx: number; sy: number; depth: number }[];
        color: string;
        highlightColor: string;
        border: string;
        avgDepth: number;
        label?: string;
      }

      const polygons: Polygon3D[] = [];

      // White luxury bouclé fabric palette
      const seatColor = "#fcfcfc";
      const seatShadow = "#dcdcdc";
      const seatHighlight = "#ffffff";

      // Precious walnut base support
      const woodColor = "#2a1c14";
      const woodShadow = "#150d09";
      const woodHighlight = "#4d2e20";

      // 6 Sofa Legs
      const buildSofaLeg = (dx: number, dz: number) => {
        const topW = 0.08, botW = 0.05, h = 0.65;
        const vTopL = project(dx - topW, h, dz - topW, "base");
        const vTopR = project(dx + topW, h, dz - topW, "base");
        const vBotL = project(dx - botW, h + 0.15, dz - botW, "base");
        const vBotR = project(dx + botW, h + 0.15, dz - botW, "base");
        polygons.push({
          points: [vTopL, vTopR, vBotR, vBotL],
          color: woodShadow,
          highlightColor: woodHighlight,
          border: woodShadow,
          avgDepth: (vTopL.depth + vBotR.depth) / 2
        });
      };
      buildSofaLeg(-0.95, -0.45);
      buildSofaLeg(0, -0.45);
      buildSofaLeg(0.95, -0.45);
      buildSofaLeg(-0.95, 0.45);
      buildSofaLeg(0, 0.45);
      buildSofaLeg(0.95, 0.45);

      // Wood platform base support (spans from -1.1 to 1.1)
      const p1 = project(-1.1, 0.62, -0.5, "base");
      const p2 = project(1.1, 0.62, -0.5, "base");
      const p3 = project(1.1, 0.62, 0.5, "base");
      const p4 = project(-1.1, 0.62, 0.5, "base");
      const p1_b = project(-1.1, 0.68, -0.5, "base");
      const p2_b = project(1.1, 0.68, -0.5, "base");
      const p3_b = project(1.1, 0.68, 0.5, "base");
      const p4_b = project(-1.1, 0.68, 0.5, "base");
      
      polygons.push({
        points: [p1, p2, p3, p4],
        color: woodColor,
        highlightColor: woodHighlight,
        border: woodShadow,
        avgDepth: (p1.depth + p3.depth) / 2
      });
      polygons.push({
        points: [p1_b, p2_b, p3_b, p4_b],
        color: woodShadow,
        highlightColor: woodColor,
        border: woodShadow,
        avgDepth: (p1_b.depth + p3_b.depth) / 2
      });
      polygons.push({
        points: [p1, p2, p2_b, p1_b],
        color: woodShadow,
        highlightColor: woodHighlight,
        border: woodShadow,
        avgDepth: (p1.depth + p2_b.depth) / 2
      });

      // Three premium seat cushions side-by-side
      const buildSofaSeat = (minX: number, maxX: number, labelName: string) => {
        const cy = 0.35;
        const vS1 = project(minX, cy, -0.48, "cushion");
        const vS2 = project(maxX, cy, -0.48, "cushion");
        const vS3 = project(maxX, cy, 0.45, "cushion");
        const vS4 = project(minX, cy, 0.45, "cushion");
        const vS1_b = project(minX, cy + 0.26, -0.48, "cushion");
        const vS2_b = project(maxX, cy + 0.26, -0.48, "cushion");
        const vS3_b = project(maxX, cy + 0.26, 0.45, "cushion");
        const vS4_b = project(minX, cy + 0.26, 0.45, "cushion");

        polygons.push({
          points: [vS1, vS2, vS3, vS4],
          color: seatColor,
          highlightColor: seatHighlight,
          border: seatShadow,
          avgDepth: (vS1.depth + vS3.depth) / 2,
          label: labelName
        });
        polygons.push({
          points: [vS1, vS2, vS2_b, vS1_b],
          color: seatShadow,
          highlightColor: seatColor,
          border: seatShadow,
          avgDepth: (vS1.depth + vS2_b.depth) / 2
        });
        polygons.push({
          points: [vS2, vS3, vS3_b, vS2_b],
          color: "#e2e8f0",
          highlightColor: seatHighlight,
          border: seatShadow,
          avgDepth: (vS2.depth + vS3_b.depth) / 2
        });
        polygons.push({
          points: [vS4, vS1, vS1_b, vS4_b],
          color: "#cbd5e1",
          highlightColor: seatHighlight,
          border: seatShadow,
          avgDepth: (vS4.depth + vS1_b.depth) / 2
        });
      };
      buildSofaSeat(-1.0, -0.34, "Assise Gauche");
      buildSofaSeat(-0.32, 0.32, "Assise Centrale");
      buildSofaSeat(0.34, 1.0, "Assise Droite");

      // Backrest (Dossier d'exception - 3-seater backrest from -1.0 to 1.0)
      const bYTop = 0.05, bYBot = 0.52;
      const vB1 = project(-1.0, bYTop, 0.35, "backrest");
      const vB2 = project(1.0, bYTop, 0.35, "backrest");
      const vB3 = project(1.0, bYBot, 0.35, "backrest");
      const vB4 = project(-1.0, bYBot, 0.35, "backrest");
      const vB1_t = project(-1.0, bYTop, 0.48, "backrest");
      const vB2_t = project(1.0, bYTop, 0.48, "backrest");
      const vB3_t = project(1.0, bYBot, 0.48, "backrest");
      const vB4_t = project(-1.0, bYBot, 0.48, "backrest");

      polygons.push({
        points: [vB1, vB2, vB3, vB4],
        color: "#fcfcfc",
        highlightColor: "#ffffff",
        border: "#e2e8f0",
        avgDepth: (vB1.depth + vB3.depth) / 2 - 0.04,
        label: "Dossier Confort"
      });
      polygons.push({
        points: [vB2_t, vB1_t, vB4_t, vB3_t],
        color: "#e2e8f0",
        highlightColor: "#fcfcfc",
        border: "#cbd5e1",
        avgDepth: (vB1_t.depth + vB4_t.depth) / 2 + 0.04
      });
      polygons.push({
        points: [vB1, vB2, vB2_t, vB1_t],
        color: "#ffffff",
        highlightColor: "#ffffff",
        border: "#e2e8f0",
        avgDepth: (vB1.depth + vB2_t.depth) / 2
      });

      // Left & Right Armrests
      const buildArmrest = (minX: number, maxX: number, label: string) => {
        const ayTop = 0.18, ayBot = 0.55;
        const va1 = project(minX, ayTop, -0.48, "cushion");
        const va2 = project(maxX, ayTop, -0.48, "cushion");
        const va3 = project(maxX, ayTop, 0.48, "cushion");
        const va4 = project(minX, ayTop, 0.48, "cushion");
        const va1_b = project(minX, ayBot, -0.48, "cushion");
        const va2_b = project(maxX, ayBot, -0.48, "cushion");
        const va3_b = project(maxX, ayBot, 0.48, "cushion");
        const va4_b = project(minX, ayBot, 0.48, "cushion");

        polygons.push({
          points: [va1, va2, va3, va4],
          color: "#fcfcfc",
          highlightColor: "#ffffff",
          border: "#e2e8f0",
          avgDepth: (va1.depth + va3.depth) / 2 - 0.02,
          label: label
        });
        polygons.push({
          points: [va1, va2, va2_b, va1_b],
          color: "#e2e8f0",
          highlightColor: "#ffffff",
          border: "#cbd5e1",
          avgDepth: (va1.depth + va2_b.depth) / 2
        });
        polygons.push({
          points: [va2, va3, va3_b, va2_b],
          color: "#cbd5e1",
          highlightColor: "#ffffff",
          border: "#94a3b8",
          avgDepth: (va2.depth + va3_b.depth) / 2
        });
        polygons.push({
          points: [va4, va1, va1_b, va4_b],
          color: "#cbd5e1",
          highlightColor: "#ffffff",
          border: "#94a3b8",
          avgDepth: (va4.depth + va1_b.depth) / 2
        });
      };
      buildArmrest(-1.18, -0.98, "Accoudoir Gauche");
      buildArmrest(0.98, 1.18, "Accoudoir Droit");

      // Depth sorting (Painter's Algorithm)
      polygons.sort((a, b) => b.avgDepth - a.avgDepth);

      // Draw all projected 3D polygons with real ambient + directional light shaders
      polygons.forEach((p) => {
        if (p.points.length < 2) return;
        ctx.beginPath();
        ctx.moveTo(p.points[0].sx, p.points[0].sy);
        for (let i = 1; i < p.points.length; i++) {
          ctx.lineTo(p.points[i].sx, p.points[i].sy);
        }
        ctx.closePath();

        // Directional moonlight shading math
        const lightIntensity = Math.max(0.2, Math.min(1.0, 0.6 + mouseLightPos.x * 0.15 - p.avgDepth * 0.12));
        ctx.fillStyle = p.color;
        
        // Render base fill
        ctx.fill();

        // Ambient highlights overlay
        ctx.save();
        ctx.globalCompositeOperation = "source-atop";
        const grad = ctx.createLinearGradient(width / 2, 0, width / 2, height);
        grad.addColorStop(0, p.highlightColor);
        grad.addColorStop(1, "rgba(0,0,0,0.15)");
        ctx.fillStyle = grad;
        ctx.globalAlpha = lightIntensity * 0.85;
        ctx.fill();
        ctx.restore();

        // 1px Hairline outline
        ctx.strokeStyle = p.border;
        ctx.lineWidth = 1;
        ctx.globalAlpha = 0.45;
        ctx.stroke();
        ctx.globalAlpha = 1.0;

        // Draw dynamic component label labels on exploded view
        if (exploded > 0.4 && p.label) {
          const midX = p.points.reduce((acc, pt) => acc + pt.sx, 0) / p.points.length;
          const midY = p.points.reduce((acc, pt) => acc + pt.sy, 0) / p.points.length;
          
          ctx.save();
          ctx.fillStyle = "rgba(4, 6, 12, 0.85)";
          ctx.font = "10px monospace";
          const tw = ctx.measureText(p.label).width;
          ctx.fillRect(midX - tw/2 - 6, midY - 18, tw + 12, 18);
          ctx.strokeStyle = "rgba(147, 197, 253, 0.3)";
          ctx.strokeRect(midX - tw/2 - 6, midY - 18, tw + 12, 18);
          ctx.fillStyle = "#f8fafc";
          ctx.fillText(p.label, midX - tw/2, midY - 6);
          ctx.restore();
        }
      });

      // Draw architectural measurement line indicators
      if (showMeasurements && exploded === 0) {
        ctx.save();
        ctx.strokeStyle = "rgba(147, 197, 253, 0.35)";
        ctx.fillStyle = "rgba(147, 197, 253, 0.85)";
        ctx.font = "10px monospace";
        ctx.lineWidth = 1;
        ctx.setLineDash([2, 3]);

        // Width dimension line (Left armrest outer edge to Right armrest outer edge)
        const mwL = project(-1.18, 0.55, -0.4, "base");
        const mwR = project(1.18, 0.55, -0.4, "base");
        
        ctx.beginPath();
        ctx.moveTo(mwL.sx, mwL.sy);
        ctx.lineTo(mwR.sx, mwR.sy);
        ctx.stroke();
        ctx.fillText("2.36m (Largeur)", (mwL.sx + mwR.sx) / 2 - 40, (mwL.sy + mwR.sy) / 2 + 15);

        // Height dimension line (Floor to top of backrest)
        const mhB = project(1.1, 0.65, 0.45, "base");
        const mhT = project(1.1, 0.05, 0.45, "backrest");

        ctx.beginPath();
        ctx.moveTo(mhB.sx, mhB.sy);
        ctx.lineTo(mhT.sx, mhT.sy);
        ctx.stroke();
        ctx.fillText("0.78m (Hauteur)", Math.max(mhB.sx, mhT.sx) + 8, (mhB.sy + mhT.sy) / 2 + 4);

        // Depth dimension line (Front cushion edge to rear backrest edge)
        const mdF = project(-1.15, 0.35, -0.48, "cushion");
        const mdB = project(-1.15, 0.35, 0.48, "cushion");

        ctx.beginPath();
        ctx.moveTo(mdF.sx, mdF.sy);
        ctx.lineTo(mdB.sx, mdB.sy);
        ctx.stroke();
        ctx.fillText("0.96m (Profondeur)", (mdF.sx + mdB.sx) / 2 - 60, (mdF.sy + mdB.sy) / 2 - 5);

        ctx.restore();
      }

      animationId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationId);
    };
  }, [angleX, angleY, zoom, exploded, showMeasurements, mouseLightPos]);

  return (
    <section 
      id="hero-showroom-section"
      ref={containerRef}
      onMouseMove={handleMouseMoveLight}
      className="relative min-h-screen flex flex-col lg:flex-row items-center justify-between overflow-hidden bg-gradient-to-b from-[#02040a] via-[#070b18] to-[#010205] transition-all duration-1000 px-6 lg:px-16 pt-24 pb-12"
    >
      {/* GLOWING AMBIENT LIGHT INDICATOR */}
      <div 
        className="absolute w-[600px] h-[600px] rounded-full blur-[140px] pointer-events-none transition-all duration-1000"
        style={{
          background: "radial-gradient(circle, rgba(96,165,250,0.08) 0%, rgba(0,0,0,0) 70%)",
          left: `${(mouseLightPos.x + 1) * 35}%`,
          top: `${(mouseLightPos.y + 1) * 35}%`,
        }}
      />

      {/* LEFT PANEL: LUXURY DETAILS */}
      <div className="w-full lg:w-5/12 z-10 text-white flex flex-col justify-center space-y-6 lg:pr-8">
        <div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-serif tracking-tight leading-none text-stone-100">
            {product.name}
          </h1>
          <p className="text-xl sm:text-2xl text-amber-200/90 mt-2 font-arabic font-medium">
            {product.arabicName} — Collection {product.collection}
          </p>
        </div>

        <p className="text-stone-300 text-sm sm:text-base font-light leading-relaxed">
          {product.description}
        </p>

        {/* PRICING DETAILS */}
        <div className="p-5 rounded-2xl bg-stone-950/40 border border-white/5 backdrop-blur-md space-y-4">
          <div className="flex justify-between items-baseline">
            <span className="text-stone-400 text-xs uppercase font-mono tracking-wider">Tarif de Prestige</span>
            <span className="text-2xl sm:text-3xl font-serif text-amber-200/95 font-bold">
              {product.basePrice.toLocaleString("fr-DZ")} DZD
            </span>
          </div>

          <div className="flex justify-between items-center text-xs pt-1 border-t border-white/5">
            <span className="text-stone-400 uppercase font-mono tracking-wider">Revêtement</span>
            <span className="text-stone-200 font-medium">{selectedMaterial.name} ({selectedMaterial.type})</span>
          </div>
        </div>

        {/* ACTIONS */}
        <div className="flex flex-col sm:flex-row gap-4 pt-2">
          <button
            id="add-to-cart-hero-btn"
            onClick={() => {
              const el = document.getElementById("appointment-contact-section");
              if (el) {
                el.scrollIntoView({ behavior: "smooth" });
              } else {
                onPlaceInPlanner(product.id);
              }
            }}
            className="flex-1 px-8 py-4 bg-sky-950/80 hover:bg-sky-900 border border-sky-500/30 text-sky-200 hover:text-white font-medium text-sm rounded-xl transition-all shadow-lg hover:shadow-sky-500/10 cursor-pointer text-center font-mono tracking-wider uppercase text-[11px]"
          >
            Prendre Rendez-vous / Devis
          </button>
          
          <a
            href="#showroom-viewer"
            onClick={(e) => {
              e.preventDefault();
              const el = document.getElementById("showroom-viewer");
              el?.scrollIntoView({ behavior: "smooth" });
            }}
            className="px-6 py-4 bg-white/5 hover:bg-white/10 active:bg-white/15 border border-white/10 text-stone-200 hover:text-white font-medium text-sm rounded-xl transition-all cursor-pointer text-center font-mono"
          >
            Vue 3D Interactive
          </a>
        </div>
      </div>

      {/* RIGHT PANEL: IMMERSIVE 3D RENDER VIEWPORT */}
      <div id="showroom-viewer" className="w-full lg:w-6/12 relative mt-12 lg:mt-0 flex flex-col items-center">
        {/* VIEW SPEC CONTROLLERS */}
        <div className="absolute top-4 right-4 z-20 flex flex-col gap-2">
          {/* Exploded View Toggle */}
          <button
            id="toggle-exploded-view"
            onClick={() => setExploded(prev => (prev === 0 ? 1 : 0))}
            className={`p-3 rounded-xl border backdrop-blur-md transition-all ${
              exploded > 0 
                ? "bg-sky-600/20 border-sky-500/30 text-sky-400" 
                : "bg-stone-950/60 border-white/5 text-stone-400 hover:text-white"
            }`}
            title="Vue Éclatée"
          >
            <Layers className="w-5 h-5" />
          </button>

          {/* Dimensions Toggle */}
          <button
            id="toggle-measurements-view"
            onClick={() => setShowMeasurements(prev => !prev)}
            className={`p-3 rounded-xl border backdrop-blur-md transition-all ${
              showMeasurements 
                ? "bg-sky-600/20 border-sky-500/30 text-sky-400" 
                : "bg-stone-950/60 border-white/5 text-stone-400 hover:text-white"
            }`}
            title="Activer/Désactiver Dimensions"
          >
            <Maximize2 className="w-5 h-5" />
          </button>

          {/* Reset Camera Orbit */}
          <button
            id="reset-camera-orbit"
            onClick={() => {
              setAngleX(-0.6);
              setAngleY(0.2);
              setZoom(1.2);
            }}
            className="p-3 rounded-xl bg-stone-950/60 border border-white/5 text-stone-400 hover:text-white backdrop-blur-md transition-all"
            title="Réinitialiser l'Angle"
          >
            <RotateCcw className="w-5 h-5" />
          </button>
        </div>

        {/* 3D CANVAS & HOTSPOTS CONTAINER */}
        <div className="relative w-full max-w-[500px] aspect-square">
          <div className="absolute inset-0 rounded-full overflow-hidden border border-white/5 shadow-2xl bg-stone-950">
            <canvas
              ref={canvasRef}
              width={1000}
              height={1000}
              className="w-full h-full cursor-grab active:cursor-grabbing"
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
            />

            {/* HELPTIP */}
            <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-10 pointer-events-none flex items-center gap-1.5 bg-black/40 border border-white/5 backdrop-blur-md px-3 py-1.5 rounded-full text-[10px] text-stone-300 font-mono tracking-wider uppercase">
              <Compass className="w-3.5 h-3.5 animate-spin" style={{ animationDuration: '6s' }} /> Cliquez & Glissez pour Pivoter
            </div>
          </div>

          {/* INTERACTIVE HOTSPOTS INTERFACE */}
          <div className="absolute inset-0 pointer-events-none z-30">
            {SOFA_HOTSPOTS.map((spot) => {
              const pos = getHotspot2DPos(spot.x, spot.y, spot.z, spot.offsetGroup);
              if (!pos.visible) return null;

              const isActive = activeHotspotId === spot.id;

              return (
                <div
                  key={spot.id}
                  className="absolute"
                  style={{
                    left: `${pos.x}%`,
                    top: `${pos.y}%`,
                    transform: "translate(-50%, -50%)",
                  }}
                >
                  <button
                    id={`hero-hotspot-btn-${spot.id}`}
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveHotspotId(isActive ? null : spot.id);
                    }}
                    className={`w-7 h-7 rounded-full flex items-center justify-center border transition-all duration-300 pointer-events-auto cursor-pointer shadow-lg ${
                      isActive 
                        ? "bg-sky-500 border-white text-white scale-110 shadow-sky-500/50" 
                        : "bg-black/75 hover:bg-stone-900 border-sky-500/50 text-sky-400 hover:scale-105 hover:border-sky-400"
                    }`}
                    title={spot.title}
                  >
                    <span className="absolute inset-0 rounded-full bg-sky-500 animate-ping opacity-40 pointer-events-none" style={{ animationDuration: "3s" }} />
                    <Sparkles className="w-3.5 h-3.5" />
                  </button>

                  {isActive && (
                    <div
                      ref={tooltipRef}
                      className="absolute z-40 bg-stone-950/95 border border-sky-500/30 p-4 rounded-xl backdrop-blur-md w-64 shadow-2xl pointer-events-auto text-stone-200 text-left space-y-2 mt-3"
                      style={{
                        transform: "translate(-50%, 0)",
                      }}
                    >
                      <div className="flex justify-between items-start">
                        <span className="text-[9px] font-mono text-sky-400 uppercase tracking-widest">{spot.subtitle}</span>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveHotspotId(null);
                          }}
                          className="text-stone-500 hover:text-stone-300 text-xs font-mono cursor-pointer"
                        >
                          ✕
                        </button>
                      </div>
                      <h4 className="font-serif text-xs font-bold text-white uppercase tracking-wider">{spot.title}</h4>
                      <p className="text-[10px] text-stone-400 font-light leading-relaxed">{spot.desc}</p>
                      
                      <div className="flex justify-between items-center pt-2 border-t border-white/5">
                        <span className="text-[10px] font-mono text-stone-400">Prix :</span>
                        <span className="text-xs font-serif font-bold text-sky-400">{spot.price}</span>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* DYNAMIC EXPLODED VIEW SLIDER */}
        <div className="w-full max-w-[380px] mt-6 bg-stone-950/50 border border-white/5 backdrop-blur-md p-4 rounded-2xl z-10 space-y-2">
          <div className="flex justify-between text-xs text-stone-400 font-mono uppercase tracking-wider">
            <span>Vue Éclatée de la Structure</span>
            <span>{Math.round(exploded * 100)}%</span>
          </div>
          <input
            id="exploded-slider-input"
            type="range"
            min="0"
            max="1"
            step="0.01"
            value={exploded}
            onChange={(e) => setExploded(parseFloat(e.target.value))}
            className="w-full accent-sky-500 bg-stone-850 rounded-lg appearance-none h-1 cursor-pointer"
          />
        </div>
      </div>
    </section>
  );
}
